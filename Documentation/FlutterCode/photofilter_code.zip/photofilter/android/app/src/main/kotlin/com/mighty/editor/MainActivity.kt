package com.mighty.editor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
