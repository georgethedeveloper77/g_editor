class FrameModel {
  String? name;
  String? frame;

  FrameModel({this.name, this.frame});
}
