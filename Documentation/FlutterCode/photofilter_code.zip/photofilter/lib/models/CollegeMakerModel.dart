class CollegeMakerModel {
  int? itemCount;
  List<List<int>>? listCount;
  List<String>? thumbnails;

  CollegeMakerModel({this.itemCount, this.listCount, this.thumbnails});
}
