class FontData {
  String? fontName;
  String? fontFamily;

  FontData({this.fontName, this.fontFamily});
}